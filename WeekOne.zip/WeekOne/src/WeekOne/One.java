package WeekOne;

public class One {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numOne = 40;    // Assigned integer into variable.  
		
		if (numOne % 3 == 0) {     // Check if modulus is zero
			System.out.println("- Can be divided by 3: Fizz");
			
			if(numOne % 5 == 0) {                  // If the second conditions  
				System.out.print("1. FizzBuzz");   // is true then an integer is
			}									   // divided by 3 and 5 
		} 
		else if(numOne % 5 == 0) {                           // Check if second conditional modulus
			System.out.print("- Can be divided by 5: Buzz"); // is zero. If the number could 
                                                             // not be divided by 3			
			
			if(numOne % 3 == 0) {                            // Then try to divide by 3
				System.out.print("2. FizzBuzz");             // to show it can be both be
			}												 // divided by 3 and 5
		} 
		else
		{
			System.out.println("- Cannot be divided"); // In case if number could 
		}                                              // not be divided by 3 and 5
		
		
		
	}

}
